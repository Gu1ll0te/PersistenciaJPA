package com.utn.persistenciajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersistenciajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
