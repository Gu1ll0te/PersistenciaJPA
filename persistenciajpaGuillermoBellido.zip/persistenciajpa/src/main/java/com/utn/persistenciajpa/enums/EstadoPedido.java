package com.utn.persistenciajpa.enums;

public enum EstadoPedido {
    INICIADO,
    PREPARACION,
    ENTREGADO,

}
