package com.utn.persistenciajpa.enums;

public enum FormaPago {

    EFECTIVO,
    MERCADOPAGO,
    TRANSFERENCIA,

}
