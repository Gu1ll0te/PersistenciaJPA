package com.utn.persistenciajpa.repositorios;

import org.springframework.stereotype.Repository;

@Repository
public interface RubroRepository {
}
