package com.utn.persistenciajpa.enums;

public enum TipoProducto {
        MANUFACTURADO,
        INSUMO,


}
