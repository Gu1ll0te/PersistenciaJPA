package com.utn.persistenciajpa.enums;

public enum TipoEnvio {

    DELIVERY,
    RETIROLOCAL,

}
